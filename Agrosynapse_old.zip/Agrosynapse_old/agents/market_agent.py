def get_top_demand_crops():
    return ['Wheat', 'Rice', 'Maize']
