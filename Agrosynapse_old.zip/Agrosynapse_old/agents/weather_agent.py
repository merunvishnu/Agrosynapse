def get_forecast():
    return {'rainfall': 'moderate', 'temperature': '25C'}
